
-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `dish_name` tinytext NOT NULL,
  `description` text NOT NULL,
  `price` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `menu`
--

INSERT INTO `menu` (`id`, `dish_name`, `description`, `price`) VALUES
(1, 'Simple Pizza', 'Cheese, onion, olives', 100);
