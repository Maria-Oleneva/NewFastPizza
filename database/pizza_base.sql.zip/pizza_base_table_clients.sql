
-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `phone_number` bigint(10) UNSIGNED NOT NULL COMMENT 'Phone number without first +7 or 8',
  `login` text NOT NULL,
  `password` text NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`id`, `phone_number`, `login`, `password`, `address`) VALUES
(1, 9998765432, 'Ivan', 'Durak', 'Tsarstvo 3/9'),
(2, 12345678911, 'A', 'aaa', '_');
